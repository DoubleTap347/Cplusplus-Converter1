// ConsoleApplication1.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#include <sstream>
#include <iostream>
#include <string>
using namespace std;

void end();
void meters();
void inch();


int main() //main prompts the user with their first options: Select 1, 2 or 3.
{
	int choice = 0;
	string input;
	cout << "Select 1 for centimeters 2 for meters or 3 to exit";
	cin >> input;
	stringstream(input) >> choice;
	if (choice == 1)
	{
		inch();
	}
	else if (choice == 2)
	{
		meters();
	}
	else if (choice == 3)
		end();
	else
		cout << "Invalid input\n";
	main();
}

void inch()
{
	double cm;
	cout << "Centimeters to Inches";
	cin >> cm;
	cout << cm*0.39 << endl;
	main();
}

void meters()
{
	double meters;
	cout << "Meters to Feet";
	cin >> meters;
	cout << meters*3.28 << endl;
	main();
}

void end()
{
	exit(0);
}